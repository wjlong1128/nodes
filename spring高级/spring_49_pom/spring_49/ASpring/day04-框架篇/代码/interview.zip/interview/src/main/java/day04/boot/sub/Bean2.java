package day04.boot.sub;

import org.springframework.stereotype.Component;

@Component
public class Bean2 {
}

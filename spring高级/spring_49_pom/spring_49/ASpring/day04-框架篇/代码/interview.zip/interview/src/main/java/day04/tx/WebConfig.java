package day04.tx;

import org.springframework.context.annotation.ComponentScan;

@ComponentScan("day04.tx.app.controller")
public class WebConfig {
}

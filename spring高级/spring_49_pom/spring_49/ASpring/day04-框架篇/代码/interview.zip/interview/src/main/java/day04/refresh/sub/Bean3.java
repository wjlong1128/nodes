package day04.refresh.sub;

import org.springframework.stereotype.Component;

@Component
public class Bean3 {
}
